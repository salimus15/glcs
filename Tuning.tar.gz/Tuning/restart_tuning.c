/*CREATED BY PIERRE-YVES AQUILANTI 2011*/
#include "restart_tuning.h"


/***********************************
 *			Arguments functions        *
 ***********************************/


/* get arguments to define restart strategy */
#undef __FUNCT__
#define __FUNCT__ "restart_tuning_args_type"
PetscErrorCode restart_tuning_args_type(PetscInt * strategy){
	PetscErrorCode ierr;
	PetscBool flag;
	char actor[PETSC_MAX_PATH_LEN];


	ierr=PetscOptionsGetString(PETSC_NULL,"-restart_type",actor,PETSC_MAX_PATH_LEN-1,&flag);CHKERRQ(ierr);
	if (!flag) {
		PetscPrintf(PETSC_COMM_WORLD,"restart_tuning_args_type Error : -restart_type is not set, using default behavior.\n");
	}else{

		ierr=PetscStrcmp(actor,"simple",&flag);CHKERRQ(ierr);
		if(flag) {
			PetscPrintf(PETSC_COMM_WORLD,"Selecting strategy : %s\n","simple");
			*strategy=RESTART_SIMPLE;
			return 0;
		}

		ierr=PetscStrcmp(actor,"full",&flag);CHKERRQ(ierr);
		if(flag) {
			PetscPrintf(PETSC_COMM_WORLD,"Selecting strategy : %s\n","full");
			*strategy=RESTART_FULL;
			return 0;
		}

		ierr=PetscStrcmp(actor,"ofull",&flag);CHKERRQ(ierr);
		if(flag) {
			PetscPrintf(PETSC_COMM_WORLD,"Selecting strategy : %s\n","ofull");
			*strategy=RESTART_ORTHOG_FULL;
			return 0;
		}

		ierr=PetscStrcmp(actor,"katagiri",&flag);CHKERRQ(ierr);
		if(flag) {
			PetscPrintf(PETSC_COMM_WORLD,"Selecting strategy : %s\n","katagiri");
			*strategy=RESTART_KATAGIRI;
			return 0;
		}

		ierr=PetscStrcmp(actor,"double",&flag);CHKERRQ(ierr);
		if(flag) {
			PetscPrintf(PETSC_COMM_WORLD,"Selecting strategy : %s\n","katagiri");
			*strategy=RESTART_KATAGIRI;
			return 0;
		}

	}

	*strategy=RESTART_NONE;

	return 0;
}

/* get arguments for full strategy */
#undef __FUNCT__
#define __FUNCT__ "restart_tuning_args_full_type"
PetscErrorCode restart_tuning_args_full_type(PetscInt * restart_full_type){
	PetscErrorCode ierr;
	PetscBool flag;
	char type[PETSC_MAX_PATH_LEN];

	ierr=PetscOptionsGetString(PETSC_NULL,"-restart_type_full",type,PETSC_MAX_PATH_LEN-1,&flag);CHKERRQ(ierr);
	if(!flag){
			PetscPrintf(PETSC_COMM_WORLD,"restart_tuning_args_full_type Error : -restart_type_full is not set, using default behavior.\n");
	}else{
		ierr=PetscStrcmp(type,"hardware",&flag);CHKERRQ(ierr);
		if(flag) {
			PetscPrintf(PETSC_COMM_WORLD,"Selecting full restart strategy : %s\n","hardware");
			*restart_full_type=RESTART_FULL_HARDWARE;
			return 0;
		}
	}

	*restart_full_type=RESTART_FULL_SIMPLE;

	return 0;
}


#undef __FUNCT__
#define __FUNCT__ "restart_tuning_args_restart"
PetscErrorCode restart_tuning_args_restart(PetscInt * min_restart, PetscInt * max_restart, PetscInt * incr){
	PetscErrorCode ierr;
	PetscBool flag;
	PetscInt minres;
	PetscInt maxres;
	PetscInt increment;

	ierr=PetscOptionsGetInt(PETSC_NULL,"-ksp_gmres_restart_min",&minres,&flag);CHKERRQ(ierr);
	if(!flag && minres<=3){
			PetscPrintf(PETSC_COMM_WORLD,"restart_tuning_args_restart Error : -ksp_gmres_restart_min is not set, using default behavior.\n");
			*min_restart=(PetscInt)3;
	}else{
		if(flag) {
			PetscPrintf(PETSC_COMM_WORLD,"restart_tuning_args_minrestart minimum restart : %d\n",minres);
			*min_restart=minres;
		}
	}

	ierr=PetscOptionsGetInt(PETSC_NULL,"-ksp_gmres_restart",&maxres,&flag);CHKERRQ(ierr);
	if(!flag && maxres<=3){
			PetscPrintf(PETSC_COMM_WORLD,"restart_tuning_args_restart Error : -ksp_gmres_restart is not set, using default behavior.\n");
			*max_restart=(PetscInt)30;
	}else{
		if(flag) {
			PetscPrintf(PETSC_COMM_WORLD,"restart_tuning_args_minmax_restart maximum restart : %d\n",maxres);
			*max_restart=maxres;
		}
	}

	increment=(PetscInt)2;
	ierr=PetscOptionsGetInt(PETSC_NULL,"-ksp_gmres_increment",&increment,&flag);CHKERRQ(ierr);
	if(!flag && increment<=2){
			PetscPrintf(PETSC_COMM_WORLD,"restart_tuning_args_restart Error : -ksp_gmres_increment is not set, using default behavior.\n");
			*incr=(PetscInt)2;
	}else{
		if(flag) {
			PetscPrintf(PETSC_COMM_WORLD,"restart_tuning_args_minmax_restart increment : %d\n",increment);
			*incr=increment;
		}
	}


	return 0;
}


/***********************************
 *	 	 Initialization functions    *
 ***********************************/

#undef __FUNCT__
#define __FUNCT__ "restart_tuning_init"
int restart_tuning_init(TRestart * restart){
	PetscInt strategy, strat_full, minimum_restart, maximum_restart, increment;
	PetscInt levels;
	PetscInt tab_levels[3];
	int rank;

	MPI_Comm_rank(PETSC_COMM_WORLD,&rank);
	/* first get args */
	/* do we use adaptive restart */
	restart_tuning_args_type(&strategy);

	restart_tuning_args_restart(&minimum_restart, &maximum_restart, &increment);

	/* init arguments depending on the strategy */
	if(strategy==RESTART_NONE){
		PetscPrintf(PETSC_COMM_WORLD,"No restart strategy selected\n");
		levels=1;
		tab_levels[0]=maximum_restart;
		restart_tuning_init_struct(minimum_restart,maximum_restart,tab_levels,0,levels,increment,RESTART_NONE,restart);
	} else if(strategy==RESTART_SIMPLE){
		PetscPrintf(PETSC_COMM_WORLD,"Simple restart strategy selected\n");
		levels=1;
		tab_levels[0]=maximum_restart;
		restart_tuning_init_struct(minimum_restart,maximum_restart,tab_levels,0,levels,increment,RESTART_SIMPLE,restart);
	} else if(strategy==RESTART_DOUBLE){
		PetscPrintf(PETSC_COMM_WORLD,"Double restart strategy selected\n");
		levels=1;
		tab_levels[0]=maximum_restart;
		restart_tuning_init_struct(minimum_restart,maximum_restart,tab_levels,0,levels,increment,RESTART_DOUBLE,restart);
	} else if(strategy==RESTART_KATAGIRI){
		PetscPrintf(PETSC_COMM_WORLD,"Katagiri restart strategy selected\n");
		levels=1;
		tab_levels[0]=maximum_restart;
		restart_tuning_init_struct(minimum_restart,maximum_restart,tab_levels,0,levels,increment,RESTART_KATAGIRI,restart);
	} else {
		/* what type of full restart do we have ? */
		PetscPrintf(PETSC_COMM_WORLD,"Full restart strategy selected\n");
		restart_tuning_args_full_type(&strat_full);
			PetscPrintf(PETSC_COMM_WORLD,"Initiating full restart array\n");
			restart_tuning_init_compute_user_restart(maximum_restart*3, maximum_restart*9, rank, &levels,tab_levels);
		PetscPrintf(PETSC_COMM_WORLD,"Initiating full restart structure\n");
		if(strategy==RESTART_FULL)
			restart_tuning_init_struct(minimum_restart,maximum_restart, tab_levels, 3,levels,increment,RESTART_FULL,restart);
		else
			restart_tuning_init_struct(minimum_restart,maximum_restart, tab_levels, 3,levels,increment,RESTART_ORTHOG_FULL,restart);
	}
	PetscPrintf(PETSC_COMM_WORLD,"End of restart strategy initialization\n");
	/* secondly init the structure */

	/* then init the restart */


	return 0;
}


#undef __FUNCT__
#define __FUNCT__ "restart_tuning_init_struct"
/* init residual history structure */
int restart_tuning_init_struct(int m_min, int m_max, int * levels, int m_counter_max, int m_levels, int incr, int strat, TRestart * myrestart){
  int i;

	myrestart->m_min=m_min;
	myrestart->m_max=m_max;
	myrestart->m_incr=incr;

	if(m_levels>0){
	  myrestart->levels=malloc((m_levels)*sizeof(int));

	  for(i=0;i<m_levels;i++)
	    myrestart->levels[i]=levels[i];
	}
	myrestart->m_levels=m_levels;
	myrestart->cpt_floor=0;
	myrestart->cpt_level=0;
	myrestart->m_floors=m_counter_max;

	myrestart->strategy=strat;


  return 0;
}

#undef __FUNCT__
#define __FUNCT__ "restart_tuning_destroy"
int restart_tuning_destroy(TRestart * myrestart){
	if(myrestart->m_levels>0)
  	free(myrestart->levels);

  return 0;
}

/***********************************
 *	 Full Restart Init functions   *
 ***********************************/

/* compute the restart for a particular hardware memory level */
#undef __FUNCT__
#define __FUNCT__ "restart_tuning_init_hardware_level"
int restart_tuning_init_hardware_level(int nnz, int n, int sizeval, double sizemem, int * m){
	double delta;
	double x1,x2;

	double a, b,c;


	a=1.;
	b=(double)(n+1);
	c=(double)(nnz+4*n-sizemem/sizeval);

	delta=pow(b,2)-4*a*c;


	if(delta!=0){
		x1=(-b-sqrt(delta))/(2*a);
		x2=(-b+sqrt(delta))/(2*a);
	}else{
		x1=x2=-b/(2*a);
	}

	if(x1>x2){
		*m=(int)floor(x1);
		return 0;
	}else{
		*m=(int)floor(x2);
		return 0;
	}
}

/* compute restart for cache and ram memory levels  */
#undef __FUNCT__
#define __FUNCT__ "restart_tuning_init_compute_hardware_restart"
int restart_tuning_init_compute_hardware_restart(int nnz, int n, int sizeval, int size_cache, double size_ram, float ratio, int m_user, int m_xtrem, int mpi_id, int * restart_level, int * levels){
	int m_cache;
	int m_ram;
	int m_tmp;

	(*restart_level)=0;

	/* compute restart thanks to available cache */
	restart_tuning_init_hardware_level(nnz,n,sizeval,size_cache,&m_tmp);
	m_cache=(int)floor(((float)m_tmp)*ratio);

	/* compute restart thanks to available ram */
	restart_tuning_init_hardware_level(nnz,n,sizeval,size_ram,&m_tmp);
	m_ram=(int)floor(((float)m_tmp)*ratio);

	/* controlling cache memory */
	if(m_cache <= 0){
		(*restart_level)=0;
		if(mpi_id==0)
			printf("m_cache (%d) is to low, switching to m_ram\nTry to use more nodes if possible\n",m_cache);
	} else if (m_cache<m_user){
		(*restart_level)=0;
		if(mpi_id==0)
			printf("m_cache (%d) lower than m_user, switching to m_ram\nTry to use more nodes if possible or use a lower m_user\n",m_cache);
	} else {
		levels[*restart_level]=m_cache;
		(*restart_level)++;
		if(mpi_id==0)
			printf("m_cache (%d) is ok, using it as level[%d]\n",m_cache,*restart_level);
	}

    /* generally the next condition is right*/
    if(m_xtrem<m_ram){
      levels[*restart_level]=m_xtrem;
      (*restart_level)++;
      if(mpi_id==0)
            printf("m_xtrem (%d) is ok, using it as  level[%d]\n",m_xtrem,*restart_level);
      return 0;
    } else {
      if(mpi_id==0)
            printf("m_ram (%d) is to low\nTry to use more nodes\n",m_ram);
        return 1;
    }

}

#undef __FUNCT__
#define __FUNCT__ "restart_tuning_init_compute_user_restart"
int restart_tuning_init_compute_user_restart(int l1, int l2, int mpi_id, int * nlevels, int * levels){
	/* define levels depending on user provided values */
	(*nlevels)=0;

	if(l1<=0 || l2 <=0){
		if(mpi_id==0)
			printf("Error: restart_tuning_init_compute_user_restart: l1=%d, l2=%d\n",l1,l2);
		return 1;
	}

	if(l1<l2){
		levels[(*nlevels)++]=l1;
		levels[(*nlevels)++]=l2;
	} else {
		levels[(*nlevels)++]=l2;
		levels[(*nlevels)++]=l1;
	}

	return 0;
}

/***********************************
 *			Processing functions       *
 ***********************************/


/* From baker and Jessup, just simple restart decrease strategy  */
#undef __FUNCT__
#define __FUNCT__ "restart_tuning_strategy_simple"
int restart_tuning_strategy_simple(float resid, float presid, TRestart * restart, int * m){
  float max_cr = (float)cos(8.*PETSC_PI/180.);
  float min_cr = (float)cos(80.*PETSC_PI/180.);
  float cr;

  cr=resid/presid;

  if(cr<0. || cr>1.){
		PetscPrintf(PETSC_COMM_WORLD,"cr=%d %f/%f\n",cr,resid,presid);

		return 1;
	}


  if(cr > max_cr){
    *m = restart->m_max;
  } else if(cr < min_cr){
    return 0;
  } else {
    if(*m-restart->m_incr >= restart->m_min){
      *m=*m-restart->m_incr;
    } else {
      *m = restart->m_max;
    }
  }

	PetscPrintf(PETSC_COMM_WORLD,"SIMPLE cr=%f m_previous=%d\n",cr,*m);

  return 0;

}


/* From katagiri, just simple restart decrease strategy  */
#undef __FUNCT__
#define __FUNCT__ "restart_tuning_strategy_katagiri"
int restart_tuning_strategy_katagiri(TRestart * restart, int * m){

  if(*m<restart->m_max)
	*m+=2;
  else
	*m=2;


  return 0;

}



#undef __FUNCT__
#define __FUNCT__ "restart_tuning_strategy_double"
int restart_tuning_strategy_double(float resid, float presid, TRestart * restart, int * m){
  float max_cr = (float)cos(8.*PETSC_PI/180.);
  float min_cr = (float)cos(16.*PETSC_PI/180.);
  float cr;

  cr=resid/presid;

  if(cr<0. || cr>1.){
		PetscPrintf(PETSC_COMM_WORLD,"cr=%d %f/%f\n",cr,resid,presid);

		return 1;
	}


  if(cr > max_cr){
    *m = restart->m_max;
  } else if(cr < min_cr && *m+restart->m_incr<restart->m_max){
    *m = *m+restart->m_incr;
  } else {
    if(*m-restart->m_incr >= restart->m_min){
      *m=*m-restart->m_incr;
    } else {
      *m = restart->m_max;
    }
  }

	PetscPrintf(PETSC_COMM_WORLD,"DOUBLE cr=%f (min=%f , max=%f) m_previous=%d\n",cr,min_cr,max_cr,*m);

  return 0;

}


/* full restart function with increase and decrease possibility  */
#undef __FUNCT__
#define __FUNCT__ "restart_tuning_strategy_full"
int restart_tuning_strategy_full(float resid, float presid, TRestart * restart, int * m){
	float cr;
	float max_cr = (float)cos(8.*PETSC_PI/180.);
	float min_cr = (float)cos(80.*PETSC_PI/180.);


	cr=resid/presid;

	if(cr<0.){
		return 1;
	}

  if(restart->cpt_floor>restart->m_floors){
    *m= restart->m_max;
    restart->cpt_floor=0;
    if(restart->cpt_level<(restart->m_levels-1)){
      restart->cpt_level++;
    }else {
      restart->cpt_level=0;
    }
  } else if(cr > max_cr && cr<1.){ /* if angle is good we keep restart parameter as it is  */
		*m = restart->m_max;

		restart->cpt_floor=0;
		restart->cpt_level=0;

	} else if(cr<max_cr && cr>min_cr  && cr<1.){/* average angle, we just decrease the restart */
		if(*m-restart->m_incr >= restart->m_min && restart->cpt_floor==0){
        *m=*m-restart->m_incr;
        } else {
        *m = restart->m_max;
        }

		restart->cpt_floor=0;
		restart->cpt_level=0;

	} else if(cr<=min_cr || cr<= 1.){	/* under minimum angle */
        if(restart->cpt_floor<restart->m_floors){
          if((*m)*2 <= restart->levels[restart->cpt_level]){
            *m=(*m)*2;
            restart->cpt_floor++;
          } else {
            *m=restart->levels[restart->cpt_level];
            restart->cpt_floor=restart->m_floors+1;
          }
        }else if(restart->cpt_floor==restart->m_floors) {
          *m=restart->levels[restart->cpt_level];
          restart->cpt_floor=restart->m_floors+1;
        }

        if(restart->cpt_level>(restart->m_levels-1)){
          restart->cpt_level=0;
        }

	}

	PetscPrintf(PETSC_COMM_WORLD,"FULL cr=%d m_previous=%d\n",cr,*m);

  return 0;
}


/* full restart function with increase and decrease possibility  */
#undef __FUNCT__
#define __FUNCT__ "restart_tuning_strategy_full_orthog"
int restart_tuning_strategy_full_orthog(float resid, float presid, TRestart * restart, int * m, int * k){
	float cr;
	float max_cr = (float)cos(8.*PETSC_PI/180.);
	float min_cr = (float)cos(80.*PETSC_PI/180.);
	int kdec=10;

	cr=resid/presid;

	if(cr<0.){
		return 1;
	}

  if(restart->cpt_floor>restart->m_floors){
    *m= restart->m_max;
		*k=restart->m_max;
    restart->cpt_floor=0;
    if(restart->cpt_level<(restart->m_levels-1)){
      restart->cpt_level++;
    }else {
      restart->cpt_level=0;
    }
  } else if(cr > max_cr && cr<1.){ /* if angle is good we keep restart parameter as it is  */
		*m = restart->m_max;

		restart->cpt_floor=0;
		restart->cpt_level=0;

		/* if orthog is over minimum (restart->m_max/4)*/
		if(*k-kdec>restart->m_max/4){
			*k=*k-kdec;
		} else {
			*k=restart->m_max;
		}

	} else if(cr<max_cr && cr>min_cr  && cr<1.){/* average angle, we just decrease the restart */
		if(*m-restart->m_incr >= restart->m_min && restart->cpt_floor==0){
      *m=*m-restart->m_incr;
    } else {
    	*m = restart->m_max;
    }

		*k=restart->m_max;
		restart->cpt_floor=0;
		restart->cpt_level=0;

	} else if(cr<=min_cr || cr> 1.){	/* under minimum angle */
        if(restart->cpt_floor<restart->m_floors){
          if((*m)*2 <= restart->levels[restart->cpt_level]){
            *m=(*m)*2;
            restart->cpt_floor++;
          } else {
            *m=restart->levels[restart->cpt_level];
            restart->cpt_floor=restart->m_floors+1;
          }
        }else if(restart->cpt_floor==restart->m_floors) {
          *m=restart->levels[restart->cpt_level];
          restart->cpt_floor=restart->m_floors+1;
        }

        if(restart->cpt_level>(restart->m_levels-1)){
          restart->cpt_level=0;
        }
				*k=restart->m_max;
	}

	PetscPrintf(PETSC_COMM_WORLD,"OFULL cr=%f (min=%f,max=%f) m_previous=%d orthog=%d\n",cr,min_cr,max_cr,*m,*k);

  return 0;
}
