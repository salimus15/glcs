/*CREATED BY PIERRE-YVES AQUILANTI 2011*/
#include "orthog_tuning.h"

/* Get arguments */
#undef __FUNCT__
#define __FUNCT__ "orthog_tuning_args"
PetscErrorCode orthog_tuning_args(PetscInt * k_orthog, PetscInt * ctx_orthog, PetscInt * heur_orthog){
	PetscInt arg,ierr;
	PetscInt rarg;
	PetscBool flag;

	flag=PETSC_TRUE;

	ierr=PetscOptionsGetInt(PETSC_NULL,"-iorthog_size",&rarg,&flag);CHKERRQ(ierr);
	if (!flag || rarg<0) {
		PetscPrintf(PETSC_COMM_WORLD,"orthog_tuning_args Error : size orthogonalization is not set, we'll use 0 instead\n",rarg,flag);
		*k_orthog=-1;
	} else{
		*k_orthog=rarg;
		PetscPrintf(PETSC_COMM_WORLD,"orthog_tuning_args : size orthogonalization set to %d\n",rarg);
	}

	ierr=PetscOptionsGetInt(PETSC_NULL,"-iorthog_type",&arg,&flag);CHKERRQ(ierr);
	if (!flag || arg<0 || arg>5 ) {
		PetscPrintf(PETSC_COMM_WORLD,"orthog_tuning_args Error : orthogonalization context not set by user, using default behavior\n");
		*ctx_orthog=0;
	} else{
		*ctx_orthog=arg;
		PetscPrintf(PETSC_COMM_WORLD,"orthog_tuning_args : type orthogonalization set to %d\n",arg);
	}

	ierr=PetscOptionsGetInt(PETSC_NULL,"-iorthog_heurist",&arg,&flag);CHKERRQ(ierr);
	if (!flag || arg<0 || arg>4 ) {
		PetscPrintf(PETSC_COMM_WORLD,"orthog_tuning_args Error : orthogonalization heuristic not set by user, using default behavior\n");
		*heur_orthog=0;
	} else{
		*heur_orthog=arg;
		PetscPrintf(PETSC_COMM_WORLD,"orthog_tuning_args : heusistic orthogonalization set to %d\n",arg);
	}



	PetscFunctionReturn(0);
}



PetscErrorCode orthog_tuning_init(TOrthog * orth){
	PetscInt size;
	PetscInt type;
	PetscInt heuristic;
	PetscErrorCode ierr;

	orth->size_fixed=-1;

	ierr=orthog_tuning_args(&size,&type,&heuristic);CHKERRQ(ierr);
	printf("type %d (%d)\n",type,IMGSLAST);
	/* now that we got the parameters we can then configure the orthogonalization process*/
	/* First the type */
	if(type==ICGS){
		PetscPrintf(PETSC_COMM_WORLD,"Selecting Incomplete Classical Graham-Schmidt orthogonalization\n");
		orth->type=ICGS;
		orth->orth=orthog_tuning_cgs;
	}else if(type==IMGSLAST){
		PetscPrintf(PETSC_COMM_WORLD,"Selecting Incomplete Modified Graham-Schmidt orthogonalization with last vectors\n");
		orth->type=IMGSLAST;
		orth->orth=orthog_tuning_mgs_last;
	}	else if(type==IMGSFIRST){
		PetscPrintf(PETSC_COMM_WORLD,"Selecting Incomplete Modified Graham-Schmidt orthogonalization with first vectors\n");
		orth->type=IMGSFIRST;
		orth->orth=orthog_tuning_mgs_first;
	}	else if(type==IMGSFL){
		PetscPrintf(PETSC_COMM_WORLD,"Selecting Incomplete Modified Graham-Schmidt orthogonalization with first and last vectors\n");
		orth->type=IMGSFL;
		orth->orth=orthog_tuning_mgs_first_last;
	}	else if(type==IMGSALT){
		PetscPrintf(PETSC_COMM_WORLD,"Selecting Incomplete Modified Graham-Schmidt orthogonalization with full alternating\n");
		orth->type=IMGSALT;
		orth->orth=orthog_tuning_mgs_alternate;
	}	else if(type==IMGSALTLAST){
		PetscPrintf(PETSC_COMM_WORLD,"Selecting Incomplete Modified Graham-Schmidt orthogonalization with alternating and last incomplete\n");
		orth->type=IMGSALTLAST;
		orth->orth=orthog_tuning_mgs_alternate_last;
	} else{
		PetscPrintf(PETSC_COMM_WORLD,"No orthogonalisation type selected\n");
	}

	/* Now get size of incomplete orthogonalization */
	PetscPrintf(PETSC_COMM_WORLD,"Number of orthogonalized vectors : %d\n",size);
	orth->size_fixed=size;


	PetscPrintf(PETSC_COMM_WORLD,"Orthogonalisation heuristic : %d\n",heuristic);
	orth->heuristic=heuristic;


	PetscPrintf(PETSC_COMM_WORLD,"Orthogonalisation Dichotomy\n");
	ierr=orthog_heuristic_dichotomy_init(10,100, 100, &(orth->dic));CHKERRQ(ierr);

	PetscFunctionReturn(0);
}

PetscErrorCode orthog_tuning_listener(PetscReal present, PetscReal previous, PetscReal low_threshold, PetscReal high_treshold, PetscReal * heurist, PetscInt * order){
	PetscReal ratio;
	ratio=1.0;
	ratio=present/previous;
	PetscPrintf(PETSC_COMM_WORLD,"ratio %f : %f\n",low_threshold, ratio);


	if(heurist!=NULL){
		*heurist=ratio;
	}


	if(ratio > high_treshold && ratio<1.){ /* if angle is good we keep parameter as it is  */
		*order=0;
		return 0;
	} else if(ratio<high_treshold && ratio>low_threshold  && ratio<1.){/* average angle, we just decrease the paramter */
		*order=1;
		return 0;
	} else if(ratio<=low_threshold || ratio> 1.){	/* under minimum angle */
		*order=-1;
		return 0;
	}

	return 1;
}

PetscErrorCode orthog_tuning_actdesc(PetscInt unit, PetscInt low_threshold, PetscInt high_threshold, PetscInt * action){


	if((*action-unit)>low_threshold){
	 	 (*action)-=unit;
		PetscPrintf(PETSC_COMM_WORLD,"remove unit : action %d unit %d action-unit %d\n",(*action),unit,(*action)-unit);
	}else{
		PetscPrintf(PETSC_COMM_WORLD,"low unit : action %d low %d\n",(*action),low_threshold);

		 (*action)=high_threshold;
	}

	return 0;
}



PetscErrorCode orthog_tuning_actor(PetscInt listener_order, PetscInt unit, PetscInt low_threshold, PetscInt high_threshold, PetscInt * action){

	PetscPrintf(PETSC_COMM_WORLD,"order : %d\n",listener_order);


	switch(listener_order){
		//increase
		case 1:
						if((*action)+unit<high_threshold){
							PetscPrintf(PETSC_COMM_WORLD,"add unit : action %d unit %d action+unit %d\n",(*action),unit,(*action)+unit);
							(*action)+=unit;

						}

						else{
							PetscPrintf(PETSC_COMM_WORLD,"high unit : action %d high %d\n",(*action),high_threshold);

							(*action)=high_threshold;
						}
						PetscPrintf(PETSC_COMM_WORLD,"decrease: %d %d \n",(*action),(*action)-unit);

						break;
		//keep it
		case 0:
						PetscPrintf(PETSC_COMM_WORLD,"keep: %d \n",(*action));
						(*action)=(*action);
						break;
		case -1:

						if((*action-unit)>low_threshold){
						 	 (*action)-=unit;
							PetscPrintf(PETSC_COMM_WORLD,"remove unit : action %d unit %d action-unit %d\n",(*action),unit,(*action)-unit);
						}else{
							PetscPrintf(PETSC_COMM_WORLD,"low unit : action %d low %d\n",(*action),low_threshold);

							 (*action)=high_threshold;
							}

						PetscPrintf(PETSC_COMM_WORLD,"decrease: %d %d \n",(*action),(*action)+unit);


						break;
		default :
							PetscPrintf(PETSC_COMM_WORLD,"else:\n");
		 					break;
	}

	return 0;
}


/* Compute if wether or not we need to modify the number of orthogonalized vectors  */
// PetscErrorCode orthog_tuning_actor(PetscInt order, PetscInt * value){
//
// 	switch(order){
// 		case 1: /* need to increase */
//
// 						break;
//
//
//
//
// 		default:
// 						break;
// 	}
//
//
//
//
// }

/* heuristic, dichotomy */
PetscErrorCode orthog_heuristic_dichotomy_init(int low, int high, int kmax, TDichotomy * dic){

	PetscFunctionBegin;

	dic->high=high;
	dic->low=low;
	dic->direction=-1;

	/* by default */
  if(low==0 && high==0){
		dic->low=0;
		dic->high=kmax;
	}

	/* kind of dirty but yeah, i assum this :p */
	if(low<0)
		dic->low=0;
	else if(low>kmax)
		dic->low=0;

	if(high>kmax)
		dic->high=kmax;
	else if(low<=0)
		dic->high=kmax;

	printf("h,l = %d,%d",dic->low,dic->high);


	PetscFunctionReturn(0);
}


#undef __FUNCT__
#define __FUNCT__ "orthog_heuristic_dichotomy"
PetscErrorCode orthog_heuristic_dichotomy(TDichotomy * dic, float heuristic,int kmin, int kmax, int * kact, int * knext)
{
	int ka;
	int kholder;

  PetscFunctionBegin;

	/* get a copy of actual number of orthogonalized vectors */
	ka=*kact;

	/* get direction */
	if(heuristic>=1.){
		dic->direction=dic->direction; // completely useless but for understanding purpose
	}else if(heuristic<1.){
		dic->direction=-dic->direction;
	}


	/* compute new low and high values*/
	if(dic->high==dic->low){
		if(dic->direction>0){
			PetscPrintf(PETSC_COMM_WORLD,"inc %d -> %d\n",dic->high,dic->high+3);
			dic->high+=3;
		}else{
			PetscPrintf(PETSC_COMM_WORLD,"dec %d -> %d\n",dic->low,dic->low-3);
			dic->low-=3;
		}
	}
	PetscPrintf(PETSC_COMM_WORLD,"vals : %d - %d - %d (%d)\n",dic->low,((dic->high)-(dic->low))/2,dic->high,dic->direction);
	kholder=(int)ceil(((float)(dic->high)-(dic->low))/2.);
	if(kholder<=1) kholder+=1;
	dic->high=ka+kholder/2;
	dic->low=ka-kholder/2;

	PetscPrintf(PETSC_COMM_WORLD,"bfr: low,hl,high,dir=%d,%d,%d,%d,%f\n",dic->low,kholder,dic->high,dic->direction,heuristic);


	if(dic->high>kmax || dic->high<=kmin)
		dic->high=kmax;
	if(dic->low<kmin)
		dic->low=kmin;



	if(dic->direction==1){
		(*knext)=dic->high;
	}else if(dic->direction==-1){
		(*knext)=dic->low;
	}else{
		printf("error dir=%d\n",dic->direction);
		PetscFunctionReturn(1); // normally we shouldn't fall here but could be a life saver for debugging
	}

	PetscPrintf(PETSC_COMM_WORLD,"aft: low,hl,high,dir=%d,%d,%d,%d,%f - > %d\n",dic->low,kholder,dic->high,dic->direction,heuristic,(*knext));


  PetscFunctionReturn(0);
}




/* Classical Graham-Schmidt orthogonalization */

#undef __FUNCT__
#define __FUNCT__ "orthog_tuning_cgs"
PetscErrorCode orthog_tuning_cgs(KSP  ksp,PetscInt it)
{
  KSP_FGMRES      *fgmres = (KSP_FGMRES *)(ksp->data);
  PetscErrorCode ierr;
  PetscInt       j;
  PetscScalar    *hh,*hes,*lhh;
  PetscReal      hnrm, wnrm;
  PetscBool     refine = (PetscBool)(fgmres->cgstype == KSP_GMRES_CGS_REFINE_ALWAYS);
	PetscInt			 k,incr;

  PetscFunctionBegin;
  ierr = PetscLogEventBegin(KSP_GMRESOrthogonalization,ksp,0,0,0);CHKERRQ(ierr);
  if (!fgmres->orthogwork) {
    ierr = PetscMalloc((fgmres->max_k + 2)*sizeof(PetscScalar),&fgmres->orthogwork);CHKERRQ(ierr);
  }
  lhh = fgmres->orthogwork;

	/* fixed k */
	k=(PetscInt)ksp->k_orth;
	if(k==0 || k>it) k=it;
	incr=1;
	//	 PetscPrintf(PETSC_COMM_WORLD,"cgs kvalue : %d\n",k);



  /* update Hessenberg matrix and do unmodified Gram-Schmidt */
  hh  = HH(it-k,it);
  hes = HES(it-k,it);

  /* Clear hh and hes since we will accumulate values into them */
  for (j=0; j<=it; j=j++) {
    hh[j]  = 0.0;
    hes[j] = 0.0;
  }
  /*
     This is really a matrix-vector product, with the matrix stored
     as pointer to rows
  */
  ierr = VecMDot(VEC_VV(it+1),it+1,&(VEC_VV(0)),lhh);CHKERRQ(ierr); /* <v,vnew> */
  for (j=it-k; j<=it; j=j+incr) {
    lhh[j] = - lhh[j];
  }

  /*
         This is really a matrix vector product:
         [h[0],h[1],...]*[ v[0]; v[1]; ...] subtracted from v[it+1].
  */
  ierr = VecMAXPY(VEC_VV(it+1),it+1,lhh,&VEC_VV(0));CHKERRQ(ierr);
  /* note lhh[j] is -<v,vnew> , hence the subtraction */
  for (j=it-k; j<=it; j=j+incr) {
    hh[j]  -= lhh[j];     /* hh += <v,vnew> */
    hes[j] -= lhh[j];     /* hes += <v,vnew> */
  }
  /*
   *  the second step classical Gram-Schmidt is only necessary
   *  when a simple test criteria is not passed
   */
  if (fgmres->cgstype == KSP_GMRES_CGS_REFINE_IFNEEDED) {
		ierr=PetscPrintf(PETSC_COMM_WORLD,"Reorthogonalisation CGS\n");CHKERRQ(ierr);
    hnrm = 0.0;
    for (j=it-k; j<=it; j=j+incr) {
      hnrm  +=  PetscRealPart(lhh[j] * PetscConj(lhh[j]));
    }
    hnrm = sqrt(hnrm);
    ierr = VecNorm(VEC_VV(it+1),NORM_2, &wnrm);CHKERRQ(ierr);
    if (wnrm < 1.0286 * hnrm) {
      refine = PETSC_TRUE;
      ierr = PetscInfo2(ksp,"Performing iterative refinement wnorm %G hnorm %G\n",wnrm,hnrm);CHKERRQ(ierr);
    }
  }

  if (refine) {
		ierr=PetscPrintf(PETSC_COMM_WORLD,"Iterative Refinement CGS\n");CHKERRQ(ierr);
    ierr = VecMDot(VEC_VV(it+1),it+1,&(VEC_VV(0)),lhh);CHKERRQ(ierr); /* <v,vnew> */
    for (j=it-k; j<=it; j=j+incr) lhh[j] = - lhh[j];
    ierr = VecMAXPY(VEC_VV(it+1),it+1,lhh,&VEC_VV(0));CHKERRQ(ierr);
    /* note lhh[j] is -<v,vnew> , hence the subtraction */
    for (j=it-k; j<=it; j=j+incr) {
      hh[j]  -= lhh[j];     /* hh += <v,vnew> */
      hes[j] -= lhh[j];     /* hes += <v,vnew> */
    }
  }
  ierr = PetscLogEventEnd(KSP_GMRESOrthogonalization,ksp,0,0,0);CHKERRQ(ierr);

  PetscFunctionReturn(0);
}

/* Modified Graham-Schmidt orthogonalization */

#undef __FUNCT__
#define __FUNCT__ "orthog_tuning_mgs_last"
PetscErrorCode  orthog_tuning_mgs_last(KSP ksp,PetscInt it)
{
  KSP_FGMRES      *fgmres = (KSP_FGMRES *)(ksp->data);
  PetscErrorCode ierr;
  PetscInt       j;
  PetscScalar    *hh,*hes;
	PetscInt			 k,incr;


  PetscFunctionBegin;
  ierr = PetscLogEventBegin(KSP_GMRESOrthogonalization,ksp,0,0,0);CHKERRQ(ierr);
  /* update Hessenberg matrix and do Gram-Schmidt */

		/* fixed k */
	k=(PetscInt)ksp->k_orth;
	if(k==0 || k>it) k=it;
	incr=1;
	// PetscPrintf(PETSC_COMM_WORLD,"mgs kvalue : %d\n",k);



  hh  = HH(it-k,it);
  hes = HES(it-k,it);
  for (j=it-k; j<=it; j=j+incr) {
    /* (vv(it+1), vv(j)) */
    ierr   = VecDot(VEC_VV(it+1),VEC_VV(j),hh);CHKERRQ(ierr);
    *hes++ = *hh;
    /* vv(it+1) <- vv(it+1) - hh[it+1][j] vv(j) */
    ierr   = VecAXPY(VEC_VV(it+1),-(*hh++),VEC_VV(j));CHKERRQ(ierr);
  }
  ierr = PetscLogEventEnd(KSP_GMRESOrthogonalization,ksp,0,0,0);CHKERRQ(ierr);
  PetscFunctionReturn(0);
}

/* Modified Graham-Schmidt orthogonalization */

#undef __FUNCT__
#define __FUNCT__ "orthog_tuning_mgs_first_last"
PetscErrorCode  orthog_tuning_mgs_first_last(KSP ksp,PetscInt it)
{
  KSP_FGMRES      *fgmres = (KSP_FGMRES *)(ksp->data);
  PetscErrorCode ierr;
  PetscInt       j;
  PetscScalar    *hh,*hes;
	PetscInt			 k,incr;
	PetscInt			 orth_ctx;
	PetscInt			 k_tmp;


  PetscFunctionBegin;
  ierr = PetscLogEventBegin(KSP_GMRESOrthogonalization,ksp,0,0,0);CHKERRQ(ierr);
  /* update Hessenberg matrix and do Gram-Schmidt */

		/* fixed k */
	k=(PetscInt)ksp->k_orth;
	if(k==0 || k>it) k=it;
	incr=1;
	// PetscPrintf(PETSC_COMM_WORLD,"mgs kvalue : %d\n",k);


	hh  = HH(0,it);
	hes = HES(0,it);
	for (j=0; j<=k; j=j++) {
	//	printf("j1=%d (it-k=%d, it=%d, k=%d)\n",j,it-k,it,k);
		/* (vv(it+1), vv(j)) */
		ierr   = VecDot(VEC_VV(it+1),VEC_VV(j),hh);CHKERRQ(ierr);
		*hes++ = *hh;
		/* vv(it+1) <- vv(it+1) - hh[it+1][j] vv(j) */
		ierr   = VecAXPY(VEC_VV(it+1),-(*hh++),VEC_VV(j));CHKERRQ(ierr);
	}

	k_tmp=k+1;
	if(it-k>k) k_tmp=it-k;
  hh  = HH(k_tmp,it);
  hes = HES(k_tmp,it);
  for (j=k_tmp; j<=it; j=j++) {
			//printf("j2=%d (it-k=%d, it=%d, k=%d)\n",j,it-k,it,k);
    /* (vv(it+1), vv(j)) */
    ierr   = VecDot(VEC_VV(it+1),VEC_VV(j),hh);CHKERRQ(ierr);
    *hes++ = *hh;
    /* vv(it+1) <- vv(it+1) - hh[it+1][j] vv(j) */
    ierr   = VecAXPY(VEC_VV(it+1),-(*hh++),VEC_VV(j));CHKERRQ(ierr);
  }

  ierr = PetscLogEventEnd(KSP_GMRESOrthogonalization,ksp,0,0,0);CHKERRQ(ierr);
  PetscFunctionReturn(0);
}

/* Modified Graham-Schmidt orthogonalization */

#undef __FUNCT__
#define __FUNCT__ "orthog_tuning_mgs_first"
PetscErrorCode  orthog_tuning_mgs_first(KSP ksp,PetscInt it)
{
  KSP_FGMRES      *fgmres = (KSP_FGMRES *)(ksp->data);
  PetscErrorCode ierr;
  PetscInt       j;
  PetscScalar    *hh,*hes;
	PetscInt			 k,incr;


  PetscFunctionBegin;
  ierr = PetscLogEventBegin(KSP_GMRESOrthogonalization,ksp,0,0,0);CHKERRQ(ierr);
  /* update Hessenberg matrix and do Gram-Schmidt */

		/* fixed k */
	k=(PetscInt)ksp->k_orth;
	if(k==0 || k>it) k=it;
	incr=1;
	// PetscPrintf(PETSC_COMM_WORLD,"mgs kvalue : %d\n",k);


	hh  = HH(0,it);
	hes = HES(0,it);
	for (j=0; j<=k; j=j++) {
	//	printf("j1=%d (it-k=%d, it=%d, k=%d)\n",j,it-k,it,k);
		/* (vv(it+1), vv(j)) */
		ierr   = VecDot(VEC_VV(it+1),VEC_VV(j),hh);CHKERRQ(ierr);
		*hes++ = *hh;
		/* vv(it+1) <- vv(it+1) - hh[it+1][j] vv(j) */
		ierr   = VecAXPY(VEC_VV(it+1),-(*hh++),VEC_VV(j));CHKERRQ(ierr);
	}

  ierr = PetscLogEventEnd(KSP_GMRESOrthogonalization,ksp,0,0,0);CHKERRQ(ierr);
  PetscFunctionReturn(0);
}

#undef __FUNCT__
#define __FUNCT__ "orthog_tuning_mgs_alternate"
PetscErrorCode  orthog_tuning_mgs_alternate(KSP ksp,PetscInt it)
{
  KSP_FGMRES      *fgmres = (KSP_FGMRES *)(ksp->data);
  PetscErrorCode ierr;
  PetscInt       j;
  PetscScalar    *hh,*hes;



  PetscFunctionBegin;
  ierr = PetscLogEventBegin(KSP_GMRESOrthogonalization,ksp,0,0,0);CHKERRQ(ierr);
  /* update Hessenberg matrix and do Gram-Schmidt */

		/* fixed k */

	// PetscPrintf(PETSC_COMM_WORLD,"mgs kvalue : %d\n",k);


	hh  = HH(0,it);
	hes = HES(0,it);
	for (j=0; j<=it; j=j+2) {
	//	printf("j1=%d (it-k=%d, it=%d, k=%d)\n",j,it-k,it,k);
		/* (vv(it+1), vv(j)) */
		ierr   = VecDot(VEC_VV(it+1),VEC_VV(j),hh);CHKERRQ(ierr);
		*hes++ = *hh;
		/* vv(it+1) <- vv(it+1) - hh[it+1][j] vv(j) */
		ierr   = VecAXPY(VEC_VV(it+1),-(*hh++),VEC_VV(j));CHKERRQ(ierr);
	}

  ierr = PetscLogEventEnd(KSP_GMRESOrthogonalization,ksp,0,0,0);CHKERRQ(ierr);
  PetscFunctionReturn(0);
}

#undef __FUNCT__
#define __FUNCT__ "orthog_tuning_mgs_alternate_last"
PetscErrorCode  orthog_tuning_mgs_alternate_last(KSP ksp,PetscInt it)
{
  KSP_FGMRES      *fgmres = (KSP_FGMRES *)(ksp->data);
  PetscErrorCode ierr;
  PetscInt       j;
  PetscScalar    *hh,*hes;
	PetscInt			 k;


  PetscFunctionBegin;
  ierr = PetscLogEventBegin(KSP_GMRESOrthogonalization,ksp,0,0,0);CHKERRQ(ierr);
  /* update Hessenberg matrix and do Gram-Schmidt */

		/* fixed k */
	k=(PetscInt)ksp->k_orth;
	if(k==0 || k>it) k=it;


  hh  = HH(0,it);
  hes = HES(0,it);

	/* first loop, alternating behavior */
  for (j=0; j<=k; j=j+2) {
    /* (vv(it+1), vv(j)) */
    ierr   = VecDot(VEC_VV(it+1),VEC_VV(j),hh);CHKERRQ(ierr);
    *hes++ = *hh;
    /* vv(it+1) <- vv(it+1) - hh[it+1][j] vv(j) */
    ierr   = VecAXPY(VEC_VV(it+1),-(*hh++),VEC_VV(j));CHKERRQ(ierr);
  }


  for (j=k; j<=it; j=j++) {
    /* (vv(it+1), vv(j)) */
    ierr   = VecDot(VEC_VV(it+1),VEC_VV(j),hh);CHKERRQ(ierr);
    *hes++ = *hh;
    /* vv(it+1) <- vv(it+1) - hh[it+1][j] vv(j) */
    ierr   = VecAXPY(VEC_VV(it+1),-(*hh++),VEC_VV(j));CHKERRQ(ierr);
  }
  ierr = PetscLogEventEnd(KSP_GMRESOrthogonalization,ksp,0,0,0);CHKERRQ(ierr);
  PetscFunctionReturn(0);
}


