/*CREATED BY PIERRE-YVES AQUILANTI 2011*/
#ifndef _ORTHOG_TUNING_H_
#define _ORTHOG_TUNING_H_

#include "petsc.h"
#include "petscvec.h"
#include "petscksp.h"

	#include "fgmresimpl.h"



/*
    Routines used for the orthogonalization of the Hessenberg matrix.

    Note that for the complex numbers version, the VecDot() and
    VecMDot() arguments within the code MUST remain in the order
    given for correct computation of inner products.
*/

#define ICGS 0 /* incomplete classical graham-schmidt */ 
#define IMGSLAST 1
#define IMGSFIRST 2
#define IMGSFL 3
#define IMGSALT 4
#define IMGSALTLAST 5

#ifndef HFIXE
#define HFIXE 0
#endif

#ifndef HRAND
#define HRAND 1
#endif

#ifndef HDESC
#define HDESC 2
#endif

#ifndef HFULL
#define HFULL 3
#endif


#ifndef HDIC
#define HDIC 4
#endif

typedef struct _orthog_dichotomy{
	int low;
	int high;
	int direction;
} TDichotomy;

typedef struct _orthog_tuning{
	int type;
	int size_fixed;
	PetscErrorCode (*orth)(KSP,PetscInt);
	int heuristic;
	TDichotomy dic;
} TOrthog;



PetscErrorCode orthog_tuning_args(PetscInt * k_orthog, PetscInt * ctx_orthog, PetscInt * heur_orthog);
PetscErrorCode orthog_tuning_init(TOrthog * orth);

/* orthogonalisation method */
PetscErrorCode orthog_tuning_cgs(KSP  ksp,PetscInt it);
PetscErrorCode orthog_tuning_mgs_last(KSP ksp,PetscInt it);
PetscErrorCode  orthog_tuning_mgs_first(KSP ksp,PetscInt it);
PetscErrorCode  orthog_tuning_mgs_first_last(KSP ksp,PetscInt it);
PetscErrorCode  orthog_tuning_mgs_alternate(KSP ksp,PetscInt it);
PetscErrorCode  orthog_tuning_mgs_alternate_last(KSP ksp,PetscInt it);


PetscErrorCode orthog_tuning_listener(PetscReal present, PetscReal previous, PetscReal low_threshold, PetscReal high_treshold, PetscReal * heurist, PetscInt * order);
PetscErrorCode orthog_tuning_actor(PetscInt listener_order, PetscInt unit, PetscInt low_threshold, PetscInt high_threshold, PetscInt * action);
PetscErrorCode orthog_tuning_actdesc(PetscInt unit, PetscInt low_threshold, PetscInt high_threshold, PetscInt * action);

/* auto-tuning algorithms */
PetscErrorCode orthog_heuristic_dichotomy_init(int low, int high, int kmax, TDichotomy * dic);
PetscErrorCode orthog_heuristic_dichotomy(TDichotomy * dic, float heuristic,int kmin, int kmax, int * kact, int * knext);


#endif

