/*CREATED BY PIERRE-YVES AQUILANTI 2011*/
#ifndef _RESTART_TUNING_H
#define _RESTART_TUNING_H

#include "petsc.h"
#include "petscsys.h"
#include <math.h>
#include <stdlib.h>

/* differents types of behaviors for restart strategies */
#define RESTART_NONE 0
#define RESTART_SIMPLE 1
#define RESTART_FULL 2
#define RESTART_ORTHOG_FULL 3
#define RESTART_KATAGIRI 4
#define RESTART_DOUBLE 5

/* types of full restart strategies */
#define RESTART_FULL_HARDWARE 0
#define RESTART_FULL_SIMPLE 1


/* structure regrouping informations for restart tuning */
typedef struct _restart_tuning{
	int m_min;
	int m_max;
  int * levels;
	int m_incr;
	int m_levels;
  int m_floors;
  int cpt_floor;   
	int cpt_level;
	int strategy;
	int m_top;
} TRestart;


/* arguments functions */
PetscErrorCode restart_tuning_args_type(PetscInt * strategy);

PetscErrorCode restart_tuning_args_full_type(PetscInt * restart_full_type);

PetscErrorCode restart_tuning_args_restart(PetscInt * min_restart, PetscInt * max_restart, PetscInt * incr);

/* initialization function */
int restart_tuning_init(TRestart * restart);

int restart_tuning_init_struct(int m_min, int m_max, int * levels, int m_counter_max, int m_levels, int incr, int strat, TRestart * myrestart);

int restart_tuning_destroy(TRestart * myrestart);


/* compute restart levels for full strategy */
int restart_tuning_init_hardware_level(int nnz, int n, int sizeval, double sizemem, int * m);

int restart_tuning_init_compute_hardware_restart(int nnz, int n, int sizeval, int size_cache, double size_ram, float ratio, int m_user, int m_xtrem, int mpi_id, int * restart_level, int * levels);

int restart_tuning_init_compute_user_restart(int l1, int l2, int mpi_id, int * nlevels, int * levels);


/* restart processing functions */
int restart_tuning_strategy_simple(float resid, float presid, TRestart * restart, int * m);

int restart_tuning_strategy_full(float resid, float presid, TRestart * restart, int * m);

int restart_tuning_strategy_katagiri(TRestart * restart, int * m);

int restart_tuning_strategy_double(float resid, float presid, TRestart * restart, int * m);

/* restart processing functions with orthogonalisation */
int restart_tuning_strategy_full_orthog(float resid, float presid, TRestart * restart, int * m, int * k);

#endif
